import React from 'react'
import { Container, Navbar } from 'react-bootstrap'

function NavbarComponent() {
    return (
        <div className='nav-container'>
            <Navbar bg="primary" data-bs-theme="dark">
                <Container>
                    <Navbar.Brand href="#home">Oxford Fest</Navbar.Brand>
                   
                </Container>
            </Navbar>
        </div>
    )
}

export default NavbarComponent