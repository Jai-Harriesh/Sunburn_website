import React, { useState } from 'react'
import { Button, Form } from 'react-bootstrap'
import { useToasts } from 'react-toast-notifications';

function UserForm(props) {
    const [userFormData, setuserFormData] = useState({
        uName: "",
        phNo: "",
        usn: ""
    })
    // console.log("userFormData", userFormData);
    const { addToast } = useToasts();

    let updateDetails = (event) => {
        // console.log("updateDetails executed");
        setuserFormData({
            ...userFormData,
            [event.target.name]: event.target.value
        })
    }

    let saveData = () => {
        // do the form validation,
        // send the data to the backend/OR Parent
        props.getUserFormData(userFormData)
        setuserFormData({
            uName: "",
            phNo: "",
            usn: ""
        })
        // appearance: 'success', 'error', 'info'
        addToast('Form Submitted Successfully', { appearance: 'success' });
    }
    
    return (
        <div>
            <h1 className='text-primary my-2 text-center'>Sunburn Registration Form</h1>
            <Form className='container border rounded'>
                <Form.Group className="my-3" controlId="formBasicEmail">
                    <Form.Label>Full Name</Form.Label>
                    <Form.Control type="text" placeholder="Enter full name"
                        name='uName' value={userFormData.uName}
                        onChange={(event) => { updateDetails(event) }} />
                </Form.Group>

                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Phone No. </Form.Label>
                    <Form.Control type="text" placeholder="Enter phone no"
                        name='phNo' value={userFormData.phNo}
                        onChange={(event) => { updateDetails(event) }} />
                </Form.Group>

                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>USN</Form.Label>
                    <Form.Control type="text" placeholder="Enter USN"
                        name='usn' value={userFormData.usn}
                        onChange={(event) => { updateDetails(event) }} />
                </Form.Group>

                <Button className='mb-3' variant="primary"
                    onClick={saveData}>
                    Submit
                </Button>
            </Form>
        </div>
    )
}

export default UserForm