import React from 'react'
import { Table } from 'react-bootstrap'

function TableComp({ allFormData }) {
    return (
        <div className='mt-3'>
            <h3 className='text-primary text-center'>List of Sunburn Participants</h3>
            <Table striped bordered hover className='container'>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Full Name</th>
                        <th>Phone No.</th>
                        <th>USN</th>
                    </tr>
                </thead>
                <tbody>
                    {allFormData.map((value, index) => {
                        return <tr key={index}>
                            <td>{index + 1}</td>
                            <td>{value.uName}</td>
                            <td>{value.phNo}</td>
                            <td>{value.usn}</td>
                        </tr>
                    })}


                </tbody>
            </Table>
        </div>
    )
}

export default TableComp