import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import NavbarComponent from './components/NavbarComponent';
import UserForm from './components/UserForm';
import { useState } from 'react';
import TableComp from './components/TableComp';
import { ToastProvider } from 'react-toast-notifications';

function App() {
  const [allFormData, setallFormData] = useState([])
  console.log("allFormData", allFormData);

  // step1
  let getUserFormData = (data) => {
    console.log("parent getUserFormData executed", data);
    // to mutate allFormData state
    // 1. take a copy of the state
    // let allFormDataCopy=[...allFormData]
    // // 2. apply the necessary logic
    // allFormDataCopy.push(data)
    // // 3.set the state with the copied state
    // setallFormData(allFormDataCopy)
    // OR
    setallFormData((prevState) => [...prevState, data])
  }

  return (
    <div className="App">
      <ToastProvider
        autoDismissTimeout={3000}
        autoDismiss
        transitionDuration={3}>

        <NavbarComponent />
        {/* step2 */}
        <UserForm getUserFormData={getUserFormData} />
        {allFormData.length > 0 && <TableComp allFormData={allFormData} />}
      </ToastProvider>
    </div>
  );
}

export default App;
